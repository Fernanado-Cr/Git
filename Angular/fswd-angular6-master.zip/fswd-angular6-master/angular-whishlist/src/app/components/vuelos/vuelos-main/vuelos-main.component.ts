import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vuelos-main',
  templateUrl: './vuelos-main.component.html',
  styleUrls: ['./vuelos-main.component.css']
})
export class VuelosMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
