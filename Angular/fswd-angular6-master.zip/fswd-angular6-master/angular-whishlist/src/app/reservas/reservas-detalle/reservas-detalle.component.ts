import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reservas-detalle',
  templateUrl: './reservas-detalle.component.html',
  styleUrls: ['./reservas-detalle.component.css']
})
export class ReservasDetalleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
