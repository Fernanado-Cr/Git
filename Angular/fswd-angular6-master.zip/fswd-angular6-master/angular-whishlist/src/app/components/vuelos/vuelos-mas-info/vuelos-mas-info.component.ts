import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vuelos-mas-info',
  templateUrl: './vuelos-mas-info.component.html',
  styleUrls: ['./vuelos-mas-info.component.css']
})
export class VuelosMasInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
